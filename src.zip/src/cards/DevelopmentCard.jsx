import React from "react";
import { IoIosArrowForward } from "react-icons/io";

const DevelopmentCard = ({ card }) => {
  return (
    <div className=" w-full relative min-h-[20rem] flex justify-end items-end rounded-md roundedl"
    style={{
      background: `linear-gradient(0deg, rgba(0,0,0,1) 0%, rgba(106,106,106,0.5) 50%, rgba(255,248,248,0) 100%), url(${card.image})`
    }}
    >
      {/* <div className="overflow-hidden rounded-2xl">
        <div className="relative">
          <img
            src={card.image}
            alt={card.title}
            className="h-[20rem] hover:scale-110 cursor-pointer transition-all duration-500 ease-in-out rounded-2xl overflow-hidden"
          />
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-b from-transparent to-black opacity-80"></div>
        </div>
      </div> */}
      <div className="group">
        <div className=" flex flex-col items-center group-hover:gap-2 transition-all duration-500 ease-in-out w-[80%] text-white group-hover:bg-white rounded-md group-hover:text-black py-4 px-4 ">
          <h3 className="text-xl font-[600] font-sans uppercase ">{card.title}</h3>

          <p className="w-[30%] h-0 group-hover:h-[1px] group-hover:opacity-100 transition-all duration-500 ease-in-out bg-gradient-to-r from-black to-zinc-400 my-2"></p>

          <ul className="list-disc max-h-0 overflow-hidden group-hover:max-h-96 group-hover:opacity-100 transition-all duration-500 ease-in-out flex flex-col gap-1 ">
            {card.description?.map((des, i) => (
              <li key={i} className="text-sm ml-5 md:text-xs lg:text-sm">
                {des}
              </li>
            ))}
          </ul>
          {/* <button className="underline flex items-center gap-2 hover:gap-4 transition-all duration-500 ease-in-out">
           <IoIosArrowForward />
          </button> */}
        </div>
      </div>
    </div>
  );
};

export default DevelopmentCard;
