import CRM from './pages/CRM'
import DevelopmentSection from './pages/DevelopmentSection'

const App = () => {
  return (
    <div className='w-full'>
      <CRM />
      <DevelopmentSection />
    </div>
  )
}

export default App  