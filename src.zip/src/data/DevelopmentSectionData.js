import image1 from "../assets/images2/1.png"
import image2 from "../assets/images2/2.png"
import image3 from "../assets/images2/3.png"
import image4 from "../assets/images2/4.png"
import image5 from "../assets/images2/5.png"
import image6 from "../assets/images2/6.png"

export const developmentSection = {
  title: "Development Solutions",
  tagline: "Explore Your Potential with Our Development Solutions",
  cards: [
    {
        image: image1,
        title: "App Development",
        description: [
            "Tailored designs that reflect your brand.",
            "Seamless apps for iOS and Android.",
            "Apps that integrate and scale easily.",
            "Intuitive interfaces for better user satisfaction."
        ],
        link: ""
    },
    {
        image: image2,
        title: "App Development",
        description: [
            "Tailored designs that reflect your brand.",
            "Seamless apps for iOS and Android.",
            "Apps that integrate and scale easily.",
            "Intuitive interfaces for better user satisfaction."
        ],
        link: ""
    },
    {
        image: image3,
        title: "App Development",
        description: [
            "Tailored designs that reflect your brand.",
            "Seamless apps for iOS and Android.",
            "Apps that integrate and scale easily.",
            "Intuitive interfaces for better user satisfaction."
        ],
        link: ""
    },
    {
        image: image4,
        title: "App Development",
        description: [
            "Tailored designs that reflect your brand.",
            "Seamless apps for iOS and Android.",
            "Apps that integrate and scale easily.",
            "Intuitive interfaces for better user satisfaction."
        ],
        link: ""
    },
    {
        image: image5,
        title: "App Development",
        description: [
            "Tailored designs that reflect your brand.",
            "Seamless apps for iOS and Android.",
            "Apps that integrate and scale easily.",
            "Intuitive interfaces for better user satisfaction."
        ],
        link: ""
    },
    {
        image: image6,
        title: "App Development",
        description: [
            "Tailored designs that reflect your brand.",
            "Seamless apps for iOS and Android.",
            "Apps that integrate and scale easily.",
            "Intuitive interfaces for better user satisfaction."
        ],
        link: ""
    },
  ]
};
